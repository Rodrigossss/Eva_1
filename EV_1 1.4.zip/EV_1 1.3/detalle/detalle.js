// detalle.js

// Recuperar carrito desde localStorage o inicializar vacío
window.productosCarrito = JSON.parse(localStorage.getItem('productosCarrito')) || [];

// Función que agrega un producto al carrito y guarda en localStorage
function agregarProductoPorId(id, cantidad = 1) {
  const producto = productos.find(p => p.id === id);
  if (!producto) return console.error("Producto no encontrado");

  const item = window.productosCarrito.find(p => p.producto.id === id);
  if (item) {
    item.cantidad += cantidad;
  } else {
    window.productosCarrito.push({ producto, cantidad });
  }

  // Guardar carrito actualizado en localStorage
  localStorage.setItem('productosCarrito', JSON.stringify(window.productosCarrito));

  // Actualizar contador en el header
  actualizarContador();
}

// Actualiza el contador del carrito en el header
function actualizarContador() {
  const total = window.productosCarrito.reduce((sum, p) => sum + p.cantidad, 0);
  const contador = document.getElementById('contador-carrito');
  if (contador) contador.textContent = total;
}

// Leer el ID del producto desde localStorage
const id = parseInt(localStorage.getItem('productoSeleccionado'));

// Buscar el producto en la lista global "productos"
const producto = productos.find(p => p.id === id);

const contenedorDetalle = document.getElementById('detalle-producto');

if (producto) {
  // Insertar HTML del detalle del producto
  contenedorDetalle.innerHTML = `
  <div class="detalle-contenido">
    <div class="detalle-imagen">
      <img src="${producto.imagen}" alt="${producto.nombre}">
      <h2>${producto.nombre}</h2>
    </div>
    <div class="detalle-info">
      <p><strong>Color:</strong> ${producto.color}</p>
      <p><strong>Talla:</strong> ${producto.talla}</p>
      <p><strong>Género:</strong> ${producto.genero}</p>
      <p><strong>Precio:</strong> $${producto.precio}</p>
      <button id="btn-agregar">Agregar al carrito</button>
    </div>
  </div>
`;

  // Agregar listener al botón de "Agregar al carrito"
  const btnAgregar = document.getElementById('btn-agregar');
  btnAgregar.addEventListener('click', () => {
    agregarProductoPorId(producto.id, 1);
    alert("Producto agregado al carrito");
  });

  // Actualizar el contador al cargar la página
  actualizarContador();

} else {
  contenedorDetalle.innerHTML = `<p>Producto no encontrado</p>`;
}

// Función para el menú hamburguesa
function toggleMenu() {
  const menu = document.querySelector('header .menu');
  menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
}

// ====================== PRODUCTOS RELACIONADOS ======================
function mostrarProductosRelacionados(productoId) {
  const contenedorRelacionados = document.getElementById('productos-relacionados');

  // Copiar el array y filtrar el producto actual
  let otros = productos.filter(p => p.id !== productoId);

  // Desordenar array (algoritmo Fisher-Yates)
  for (let i = otros.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [otros[i], otros[j]] = [otros[j], otros[i]];
  }

  // Tomar los primeros 6
  const seleccionados = otros.slice(0, 6);

  // Insertar en el contenedor
  seleccionados.forEach(p => {
    const card = document.createElement('div');
    card.className = "col-md-2 producto-card text-center";
    card.innerHTML = `
      <img src="${p.imagen}" alt="${p.nombre}" class="img-fluid">
      <h6>${p.nombre}</h6>
      <p>$${p.precio}</p>
    `;

    // Click para ir al detalle
    card.addEventListener('click', () => {
      localStorage.setItem('productoSeleccionado', p.id);
      window.location.href = 'detalle.html';
    });

    contenedorRelacionados.appendChild(card);
  });
}

// Llamar a la función (si existe el producto principal)
if (producto) {
  mostrarProductosRelacionados(producto.id);
}