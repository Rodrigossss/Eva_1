function toggleMenu() {
  const menu = document.querySelector('header .menu');
  if (menu.style.display === 'block') {
    menu.style.display = 'none';
  } else {
    menu.style.display = 'block';
  }
}

const contenedor = document.getElementById('productos-container');

productos.forEach(producto => {
  const card = document.createElement('div');
  card.className = 'producto-card col';
  card.innerHTML = `
    <img src="${producto.imagen}" alt="${producto.nombre}">
    <h4>${producto.nombre}</h4>
    <p>$${producto.precio}</p>
  `;

  card.addEventListener('click', () => {
    // Guardar el ID del producto en localStorage
    localStorage.setItem('productoSeleccionado', producto.id);
    // Ir a la página detalle
    window.location.href = '../detalle/detalle.html';
  });

  contenedor.appendChild(card);
});
