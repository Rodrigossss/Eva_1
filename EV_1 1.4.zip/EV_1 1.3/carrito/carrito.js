// ===================== CARRITO GLOBAL =====================
// Inicializa el carrito desde localStorage o vacío
window.productosCarrito = JSON.parse(localStorage.getItem('productosCarrito')) || [];

// ===================== FUNCIONES PRINCIPALES =====================

// Guardar carrito en localStorage y actualizar contador/lista
function actualizarCarrito() {
  localStorage.setItem('productosCarrito', JSON.stringify(window.productosCarrito));

  // Contador del icono
  const totalContador = window.productosCarrito.reduce((sum, p) => sum + p.cantidad, 0);
  const contador = document.getElementById('contador-carrito');
  if (contador) contador.textContent = totalContador;

  // Lista de productos en carrito
  const contenedor = document.getElementById('productos-carrito');
  if (contenedor) {
    contenedor.innerHTML = '';
    window.productosCarrito.forEach((item, index) => {
      const div = document.createElement('div');
      div.className = 'producto-carrito';
      div.innerHTML = `
        <img src="${item.producto.imagen}" alt="${item.producto.nombre}" width="50">
        <span>${item.producto.nombre}</span>
        <span>Talla: ${item.producto.talla}</span>
        <span>Género: ${item.producto.genero}</span>
        <span>$${item.producto.precio}</span>
        <div class="cantidad">
          <button onclick="modificarCantidad(${index}, -1)">-</button>
          <span>${item.cantidad}</span>
          <button onclick="modificarCantidad(${index}, 1)">+</button>
        </div>
      `;
      contenedor.appendChild(div);
    });

    // Total del carrito
    const total = window.productosCarrito.reduce((sum, item) => sum + item.producto.precio * item.cantidad, 0);
    const totalSpan = document.getElementById('total-carrito');
    if (totalSpan) totalSpan.textContent = total;
  }
}

// Agregar producto por ID
function agregarProductoPorId(id, cantidad = 1) {
  const producto = productos.find(p => p.id === id);
  if (!producto) return console.error("Producto no encontrado");

  const item = window.productosCarrito.find(p => p.producto.id === id);
  if (item) {
    item.cantidad += cantidad;
  } else {
    window.productosCarrito.push({ producto, cantidad });
  }

  actualizarCarrito();
}

// Modificar cantidad desde botones +/-
function modificarCantidad(index, cambio) {
  const item = window.productosCarrito[index];
  item.cantidad += cambio;

  if (item.cantidad <= 0) {
    window.productosCarrito.splice(index, 1);
  }

  actualizarCarrito();
}

// Eliminar producto
function eliminarProducto(index) {
  window.productosCarrito.splice(index, 1);
  actualizarCarrito();
}

// ===================== VALIDAR CÓDIGO DE DESCUENTO =====================
const btnDescuento = document.getElementById('validar-descuento');
if (btnDescuento) {
  btnDescuento.addEventListener('click', () => {
    const codigo = document.getElementById('codigo-descuento').value.trim();
    let total = window.productosCarrito.reduce((sum, item) => sum + item.producto.precio * item.cantidad, 0);

    if (codigo === "DESCUENTO10") {
      total = Math.round(total * 0.9);
      alert("Código válido! Se aplicó 10% de descuento.");
    } else {
      alert("Código inválido.");
    }

    const totalSpan = document.getElementById('total-carrito');
    if (totalSpan) totalSpan.textContent = total;
  });
}

// ===================== BOTÓN PAGAR =====================
const btnPagar = document.getElementById('btn-pagar');
if (btnPagar) {
  btnPagar.addEventListener('click', () => {
    if (window.productosCarrito.length === 0) {
      alert("El carrito está vacío!");
      return;
    }
    alert("Procesando pago...");
  });
}

// ===================== MENÚ HAMBURGUESA =====================
function toggleMenu() {
  const menu = document.querySelector('header .menu');
  if (menu.style.display === 'block') {
    menu.style.display = 'none';
  } else {
    menu.style.display = 'block';
  }
}

// Cierra el menú si se hace clic fuera
document.addEventListener('click', function(e) {
  const menu = document.querySelector('header .menu');
  const btn = document.querySelector('.menu-btn');

  if (!menu.contains(e.target) && !btn.contains(e.target)) {
    menu.style.display = 'none';
  }
});

// ===================== INICIALIZAR =====================
actualizarCarrito();
