// detalle.js

// Recuperar carrito desde localStorage o inicializar vacío
window.productosCarrito = JSON.parse(localStorage.getItem('productosCarrito')) || [];

// Función que agrega un producto al carrito y guarda en localStorage
function agregarProductoPorId(id, cantidad = 1) {
  const producto = productos.find(p => p.id === id);
  if (!producto) return console.error("Producto no encontrado");

  const item = window.productosCarrito.find(p => p.producto.id === id);
  if (item) {
    item.cantidad += cantidad;
  } else {
    window.productosCarrito.push({ producto, cantidad });
  }

  // Guardar carrito actualizado en localStorage
  localStorage.setItem('productosCarrito', JSON.stringify(window.productosCarrito));

  // Actualizar contador en el header
  actualizarContador();
}

// Actualiza el contador del carrito en el header
function actualizarContador() {
  const total = window.productosCarrito.reduce((sum, p) => sum + p.cantidad, 0);
  const contador = document.getElementById('contador-carrito');
  if (contador) contador.textContent = total;
}

// Leer el ID del producto desde localStorage
const id = parseInt(localStorage.getItem('productoSeleccionado'));

// Buscar el producto en la lista global "productos"
const producto = productos.find(p => p.id === id);

const contenedorDetalle = document.getElementById('detalle-producto');

if (producto) {
  // Insertar HTML del detalle del producto
  contenedorDetalle.innerHTML = `
    <div class="col-md-6">
      <img src="${producto.imagen}" alt="${producto.nombre}" class="img-fluid">
    </div>
    <div class="col-md-6">
      <h2>${producto.nombre}</h2>
      <p>Color: ${producto.color}</p>
      <p>Talla: ${producto.talla}</p>
      <p>Género: ${producto.genero}</p>
      <p>Precio: $${producto.precio}</p>
      <button id="btn-agregar">Agregar al carrito</button>
    </div>
  `;

  // Agregar listener al botón de "Agregar al carrito"
  const btnAgregar = document.getElementById('btn-agregar');
  btnAgregar.addEventListener('click', () => {
    agregarProductoPorId(producto.id, 1);
    alert("Producto agregado al carrito");
  });

  // Actualizar el contador al cargar la página
  actualizarContador();

} else {
  contenedorDetalle.innerHTML = `<p>Producto no encontrado</p>`;
}

// Función para el menú hamburguesa
function toggleMenu() {
  const menu = document.querySelector('header .menu');
  menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
}

