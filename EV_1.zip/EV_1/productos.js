const productos = [
  {
    id: 1,
    imagen: "../images/camiseta.png",
    nombre: "Camiseta",
    color: "Negro",
    talla: "XL",
    genero: "H",
    precio: 12990
  },
  {
    id: 2,
    imagen: "../images/zapatillas.png",
    nombre: "Zapatillas",
    color: "Azul",
    talla: "44",
    genero: "M",
    precio: 89990
  },
  {
    id: 3,
    imagen: "../images/jeans.jpg",
    nombre: "Jeans",
    color: "Azul",
    talla: "40-42",
    genero: "H",
    precio: 10990
  }
];