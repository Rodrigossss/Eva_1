function toggleMenu() {
  const menu = document.getElementById("menu");
  menu.classList.toggle("show");
}