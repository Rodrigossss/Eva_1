// - Validar Email 
function validarEmail(email) {
  const dominios = ["@duoc.cl", "@profesor.duoc.cl", "@gmail.com"];

  for (let i = 0; i < dominios.length; i++) {
    if (email.endsWith(dominios[i])) {
      return true; 
    }
  }
  return false; 
}

// - Validacion Login 
function validarLogin() {
  let email = document.getElementById("email").value.trim();
  let contraseña = document.getElementById("contraseña").value.trim();
  let errores = [];

  if (!email || email.length > 100 || !validarEmail(email)) {
    errores.push("El correo debe ser válido y terminar en @duoc.cl, @profesor.duoc.cl o @gmail.com.");
  }
  if (!contraseña || contraseña.length < 4 || contraseña.length > 10) {
    errores.push("La contraseña debe tener entre 4 y 10 caracteres.");
  }

  document.getElementById("errores").innerHTML = errores.join("");
  return errores.length === 0;
}

// - Validacion Registro
function validarRegistro() {
  let nombre = document.getElementById("nombre").value.trim();
  let email = document.getElementById("email").value.trim();
  let contraseña = document.getElementById("contraseña").value.trim();
  let confirmcontraseña = document.getElementById("confirmcontraseña").value.trim();
  let errores = [];

  if (!nombre || nombre.length > 100) {
    errores.push("El nombre requiere minimo 3 caracteres y maximo 100 .");
  }
  if (!email || email.length > 100 || !validarEmail(email)) {
    errores.push("El correo debe ser válido y terminar en @duoc.cl, @profesor.duoc.cl o @gmail.com.");
  }
  if (!contraseña || contraseña.length < 4 || contraseña.length > 10) {
    errores.push("La contraseña debe tener entre 4 y 10 caracteres.");
  }
  if (contraseña !== confirmcontraseña) {
    errores.push("Las contraseñas no coinciden.");
  }

  document.getElementById("errores").innerHTML = errores.join("");
  return errores.length === 0 ;
  
}

// - Validacion Contacto
function validarContacto() {
  let nombre = document.getElementById("nombre").value.trim();
  let email = document.getElementById("email").value.trim();
  let comentario = document.getElementById("comentario").value.trim();
  let errores = [];

  if (!nombre || nombre.length > 100) {
    errores.push("El nombre requiere (minimo 3 caracteres y maximo 100 ).");
  }
  if (!email || email.length > 100 || !validarEmail(email)) {
    errores.push("El correo debe ser válido y terminar en @duoc.cl, @profesor.duoc.cl o @gmail.com.");
  }
  if (!comentario || comentario.length > 500) {
    errores.push("El comentario es requerido (máx 500 caracteres).");
  }

  document.getElementById("errores").innerHTML = errores.join("");
  return errores.length === 0;
}


  // Botón de login
  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", function (event) {
      if (!validarLogin()) {
        event.preventDefault(); // evita que se envie si es invalido
      }
    });
  }

  // Botón de registro
  const registroForm = document.getElementById("registroForm");
  if (registroForm) {
    registroForm.addEventListener("submit", function (event) {
      if (!validarRegistro()) {
        event.preventDefault();
      }
    });
  }

  // Boton de contacto
  const contactoForm = document.getElementById("contactoForm");
  if (contactoForm) {
    contactoForm.addEventListener("submit", function (event) {
      if (!validarContacto()) {
        event.preventDefault();
      }
    });
  }
;

